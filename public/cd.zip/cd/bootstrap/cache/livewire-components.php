<?php return array (
  'test' => 'App\\Http\\Livewire\\Test',
);